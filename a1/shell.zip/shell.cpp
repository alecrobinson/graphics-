// shell.cpp

#include "shell.h"


float Shell::verts[] = {

  -1,0, 1,0,
  1,0, 0,10, 
  0,10, -1,0,

  9999
};

